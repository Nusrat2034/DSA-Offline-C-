#include <bits/stdc++.h>
using namespace std;
vector<bool> vis;
vector<int> top_order, comp;
vector<bool> assignment;

vector<vector<int>> adj, adj_T;

void addEdge(int u, int v)
{
    adj[u].push_back(v);
}

void getTranspose(int size)
{
    adj_T.resize(size);

    for (int v = 0; v < size; v++)
    {
        for (auto x : adj[v])
        {
            adj_T[x].push_back(v);
        }
    }
}

void dfs1(int v)
{
    vis[v] = true;

    for (int x : adj[v])
    {
        if (!vis[x])
            dfs1(x);
    }

    top_order.push_back(v);
}

void dfs2(int v, int cl)
{
    comp[v] = cl;

    for (int x : adj_T[v])
    {
        if (comp[x] == -1)
            dfs2(x, cl);
    }
}

bool satisfiable(int s)
{
    top_order.clear();

    vis.assign(s, false);
    for (int i = 0; i < s; i++)
    {
        if (!vis[i])
            dfs1(i);
    }

    comp.assign(s, -1);

    getTranspose(s);

    for (int i = 0, j = 0; i < s; ++i)
    {
        int v = top_order[s - i - 1];
        if (comp[v] == -1)
            dfs2(v, j++);
    }

    assignment.assign(s, false);

    for (int i = 0; i < s; i += 2)
    {
        if (comp[i] == comp[i + 1])
            return false;
        assignment[i] = comp[i] > comp[i + 1];
    }
    return true;
}

int main()
{
freopen("sccinput.txt", "r", stdin);
freopen("sccoutput.txt", "w", stdout);

while (!feof(stdin))
{

if (feof(stdin))
    break;
    while(!feof(stdin)){
    int c;
    cin >> c;
    cin.ignore();
    int nums = 26;
    adj.resize(2 * nums);
    int maxIndex = INT_MIN;
    int minIndex = INT_MAX;

    for (int i = 0; i < c; i++)
    {
        string clause;
        getline(cin, clause);

        if (clause.size() == 1)//a
        {
            char var = clause[0];
            int v = 2 * (var - 'a');
            int u = 2 * (var - 'a') + 1;
            addEdge(u, v);
            maxIndex = max(maxIndex, max(u, v));
            minIndex = min(minIndex, min(u, v));
        }
        else if (clause.size() == 2)//~a
        {
            char var = clause[1];
            int v = 2 * (var - 'a') + 1;
            int u = 2 * (var - 'a');
            maxIndex = max(maxIndex, max(u, v));
            minIndex = min(minIndex, min(u, v));
            addEdge(u, v);
        }
        else if (clause.size() == 3)//a b
        {
            char var1 = clause[0];
            char var2 = clause[2];

            int u1 = 2 * (var1 - 'a') + 1;
            int v1 = 2 * (var2 - 'a');
            int u2 = 2 * (var2 - 'a') + 1;
            int v2 = 2 * (var1 - 'a');
            addEdge(u1, v1);
            addEdge(u2, v2);

            int max1 = max(u1, v1);
            maxIndex = max(maxIndex, max(max1, max(u2, v2)));
            minIndex = min(minIndex, min(v2, min(u2, min(u1, v1))));
        }
        else if (clause.size() == 4)
        {
            if (clause[0] == '~')//~a b
            {
                char var1 = clause[1];
                char var2 = clause[3];
                int u1 = 2 * (var1 - 'a');
                int v1 = 2 * (var2 - 'a');
                int u2 = 2 * (var2 - 'a') + 1;
                int v2 = 2 * (var1 - 'a') + 1;
                addEdge(u1, v1);
                addEdge(u2, v2);
                int max1 = max(u1, v1);
                maxIndex = max(maxIndex, max(max1, max(u2, v2)));
                minIndex = min(minIndex, min(v2, min(u2, min(u1, v1))));
            }
            else
            {
                char var1 = clause[0];//a ~b
                char var2 = clause[3];
                int u1 = 2 * (var1 - 'a') + 1;
                int v1 = 2 * (var2 - 'a') + 1;

                 int u2 = 2 * (var2 - 'a');
                int v2 = 2 * (var1 - 'a');
                int max1 = max(u1, v1);
                maxIndex = max(maxIndex, max(max1, max(u2, v2)));
                minIndex = min(minIndex, min(v2, min(u2, min(u1, v1))));
                addEdge(u1, v1);
                addEdge(u2, v2);
            }
        }
        else//~a ~b
        {
            char var1 = clause[1];
            char var2 = clause[4];
            int u1 = 2 * (var1 - 'a');
            int v1 = 2 * (var2 - 'a') + 1;
            int u2 = 2 * (var2 - 'a');
            int v2 = 2 * (var1 - 'a') + 1;
            int max1 = max(u1, v1);
            maxIndex = max(maxIndex, max(max1, max(u2, v2)));
            minIndex = min(minIndex, min(v2, min(u2, min(u1, v1))));
            addEdge(u1, v1);
            addEdge(u2, v2);
        }
    }

    int size = maxIndex + 1;
    adj.resize(maxIndex+1);
    if (!satisfiable(size))
    {
        cout << " No assignment possible" << endl;

        return 0;
    }

    for (int i = minIndex; i < size; i++)
    {
        bool value = assignment[i];
        char var = 'a' + (i / 2);
        if (i % 2 == 0)
        {
            cout << var << (value ? " true" : " false") << endl;
        }
    }
}
}
return 0;
}
