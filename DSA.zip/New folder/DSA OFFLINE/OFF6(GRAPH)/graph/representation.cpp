#include<iostream>
#include<bits/stdc++.h>
using namespace std;
class graph {

    vector<vector<int>> adj;
public:
    graph(int n) {
        adj.resize(n);
    }

    void addEdge(int u, int v) {
        adj[u].push_back(v);
  }
   int distanceBFS(int source, int destination, stack<int>& ans) {
    vector<int> parent(adj.size(), -1);
    unordered_set<int> visited;
    queue<pair<int, int>> q;
    visited.insert(source);
    q.push({source, 0});

    while (!q.empty()) {
        int node = q.front().first;
        int distance = q.front().second;
        q.pop();

        if (node == destination) {
            int curr = destination;
            while (curr != source) {
                ans.push(curr);
                curr = parent[curr];
            }
            ans.push(source);

            return distance;
        }

        for (int neighbor : adj[node]) {
            if (visited.find(neighbor) == visited.end()) {
                q.push({neighbor, distance + 1});
                visited.insert(neighbor);
                parent[neighbor] = node;
            }
        }
    }

    return -1;
}

int distanceDFS(int source, int destination, queue<int>& path) {
    static unordered_set<int> visited;
    visited.insert(source);
    path.push(source);

    if (source == destination) {
        return 0;
    }

    for (int neighbour : adj[source]) {
        if (visited.find(neighbour) == visited.end()) {
            int newDistance = distanceDFS(neighbour, destination, path);
            if (newDistance != -1) {
                return newDistance + 1;
            }
        }
    }

    path.pop();
    return -1;
}
};

int main() {
    freopen("input1.txt","r",stdin);
    freopen("output1.txt","w",stdout);
    while(!feof(stdin)){
    char p;
    cin>>p;
    if (feof(stdin))
            break;
    if(p=='B'){
    int n,m;
    cin >>n>> m;
    graph g(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        g.addEdge(u, v);
    }
    stack<int>ans;
    int s,d;
    cin>>s>>d;
    cout<< "BFS:"<<g.distanceBFS(s,d,ans)<<endl;
    while(!ans.empty()){
        cout<<ans.top()<<" ";
        ans.pop();
    }
    cout<<endl;
    }
    else if(p=='D'){
    int n,m;
    cin >>n>> m;
    graph g(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        g.addEdge(u, v);
    }
    queue<int>ans;
    int s,d;
    cin>>s>>d;
    cout<<"DFS:"<< g.distanceDFS(s,d,ans)<<endl;
    while(!ans.empty()){
        cout<<ans.front()<<" ";
        ans.pop();
    }
    cout<<endl;
    }
    }
    return 0;
}
