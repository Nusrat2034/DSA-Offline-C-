#include<iostream>
#include<vector>
using namespace std;

struct point
{
    int x;
    int y;

    point(int a,int b)
    {
        x=a;
        y=b;
    }
};

vector<point> hull;

bool isPointInVector(vector<point> vec,point p)
{
    for (auto pt : vec)
    {
        if (pt.x == p.x && pt.y == p.y)
        {
            return true;
        }
    }
    return false;
}
int findSide(point p1,point p2,point p)
{
    int val = (p.y - p1.y) * (p2.x - p1.x) -
              (p2.y - p1.y) * (p.x - p1.x);

    if (val > 0)
        return 1; // 1 is for left
    if (val < 0)
        return -1;   //-1 is for right
    return 0;   //on the line
}

int lineDist(point p1, point p2, point p)
{
    return abs ((p.y - p1.y) * (p2.x - p1.x) -
                (p2.y - p1.y) * (p.x - p1.x));
}

void quickHull(vector<point>a, int n, point p1,point p2, int side)
{
    int ind = -1;
    int max_dist = 0;
    for (int i=0; i<n; i++)
    {
        int temp = lineDist(p1, p2, a[i]);
        if (findSide(p1, p2, a[i]) == side && temp > max_dist)
        {
            ind = i;
            max_dist = temp;
        }
    }
    if (ind == -1)
    {
        hull.push_back(p1);
        hull.push_back(p2);
        return;
    }
    quickHull(a, n ,a[ind],p1,-findSide(a[ind], p1, p2));//p2 er opposite side e call hobe
    quickHull(a, n,a[ind], p2,-findSide(a[ind], p2, p1));//p1 er opposite side e call hobe
}

void printHull(vector<point>a, int n)
{
    if (n < 3)
    {
        cout << "Convex hull not possible\n";
        return;
    }
    int min_x = 0, max_x = 0;
    for (int i=0; i<n; i++)
    {
        if (a[i].x < a[min_x].x)
            min_x = i;
        if (a[i].x > a[max_x].x)
            max_x = i;
    }
    quickHull(a, n, a[min_x], a[max_x], -1);
    quickHull(a, n, a[min_x], a[max_x], 1);

    vector<point> uniqueHull;

    for (auto p : hull)
    {
        if (!isPointInVector(uniqueHull, p))
        {
            uniqueHull.push_back(p);
        }
    }

    for (auto point : uniqueHull)
    {
        cout << point.x << " " << point.y << endl;
    }
}
int main()
{
    freopen("in1.txt","r",stdin);
    freopen("out1.txt","w",stdout);
    int n;
    cin>>n;
    vector<point>a;
    for(int i=0; i<n; i++)
    {
        int x;
        int y;
        cin>>x>>y;
        a.push_back(point(x,y));
    }
    printHull(a,n);
    return 0;
}
