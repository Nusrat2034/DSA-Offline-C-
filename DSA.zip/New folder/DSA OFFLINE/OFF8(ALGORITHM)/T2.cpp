#include <iostream>
using namespace std;

void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

void sort(int *a, int n) {
for (int i = 0; i < n - 1; i++) {
    for (int j = 0; j < n - i - 1; j++) {
        if (a[j] > a[j + 1]) {
            swap(&a[j], &a[j + 1]);
        }
    }
}
}

int min_platform(int arr[], int dep[], int n)
{
    int ans=INT_MIN;
    int count=0;

    sort(arr,n);
    sort(dep,n);

    int i=0;
    int j=0;

    while(i<n){

        if(arr[i]<=dep[j]){
            count++;
            i++;
        }
        else if(arr[i]>dep[j]){
            count--;
            j++;
        }
        ans=max(ans,count);
    }
    return ans;
}

int main()
{
	freopen("in2.txt","r",stdin);
	freopen("out2.txt","w",stdout);
	while(!feof(stdin)){
    char func;
    cin>>func;
    if (feof(stdin))
    break;
    if(func=='T'){
	int n;
	cin>>n;
	int* x=new int[n];
	int* y=new int[n];
	for(int i=0;i<n;i++){
        int enter;
        int leave;
        cin>>enter>>leave;
        x[i]=enter;
        y[i]=leave;
	}
	cout<<"The minimum platform needed is "<<min_platform(x,y,n)<<endl;
	}
	}
	return 0;
}
