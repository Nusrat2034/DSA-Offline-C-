#include <iostream>
using namespace std;

template <typename T>
class heap
{
    T* a;
    int capacity;
    int it;

    void expand() {
    int* new_a = new int[2 * capacity];
    for (int i = 1; i <= it; i++) {
        new_a[i] = a[i];
    }
    delete[] a;
    a = new_a;
    capacity = 2 * capacity;
 }


    void max_heapify_up(int i)
    {
        int current = i;
        while (current > 0)
        {
            int parent = current / 2;
            if (a[parent] < a[current])
            {
                swap(a[current], a[parent]);
                current = parent;
            }
            else
            {
                return;
            }
        }
    }

    void max_heapify_down(int i, int it)
    {
        int largest = i;
        int left = 2 * i;
        if (left <= it && a[largest] < a[left])
        {
            largest = left;
        }
        int right = 2 * i + 1;
        if (right <= it && a[largest] < a[right])
        {
            largest = right;
        }

        if (largest != i)
        {
            swap(a[largest], a[i]);
            max_heapify_down(largest, it);
        }
    }

public:
    heap(int capacity)
    {
        this->capacity = capacity;
        it = 0;
        a = new T[capacity];
    }

    ~heap()
    {
        delete[] a;
    }

    void insert(T key) {
    it++;
    if (it == capacity) {
        expand();
    }
    a[it] = key;
    max_heapify_up(it);
}


    T FindMax()
    {
        return a[1];
    }

    void IncreaseKey(int i, T newKey)
    {
        if (a[i] > newKey)
        {
            cout << "New key is not larger than the previous key" << endl;
            return;
        }
        else
        {
            a[i] = newKey;
            max_heapify_up(i);
            cout << "Key increased!" << endl;
        }
    }

    void DecreaseKey(int i, T newKey)
    {
        if (a[i] < newKey)
        {
            cout << "New key is not smaller than the previous key" << endl;
            return;
        }
        else
        {
            a[i] = newKey;
            max_heapify_down(i, it);
            cout << "Key decreased!" << endl;
        }
    }

    void Sort()
    {
        int s = it;
        while (s > 1)
        {
            swap(a[1], a[s]);
            s--;
            max_heapify_down(1, s);
        }
    }

    T ExtractMax()
    {
        T n = a[1];
        swap(a[1], a[it]);
        it--;
        max_heapify_down(1, it);
        return n;
    }

    void print()
    {
        int level = 0;
        int elementsInCurrentLevel = 1;
        int elementsPrinted = 1;

        cout << "No of elements: " << it << endl;

        while (elementsPrinted <= it)
        {
            for (int i = 1; i <= elementsInCurrentLevel && elementsPrinted <= it; i++)
            {
                cout << a[elementsPrinted] << "   ";
                elementsPrinted++;
            }
            cout << endl;

            elementsInCurrentLevel *= 2;
            level++;
        }
    }
};

int main()
{
    freopen("in1.txt", "r", stdin);
    freopen("out1.txt", "w", stdout);
    heap<int> max_heap = heap<int>(5);

    int func, p;
    int i;
    while (true)
    {
        cin >> func;
        if (feof(stdin))
            break;
        if (func == 1)
        {
            cin >> p;
            max_heap.insert(p);
        }
        else if (func == 2)
        {
            cout << "Max: " << max_heap.FindMax() << endl;
        }
        else if (func == 3)
        {
            cout << "Max: " << max_heap.ExtractMax() << " has been extracted" << endl;
        }
        else if (func == 4)
        {
            cin >> i;
            cin >> p;
            max_heap.IncreaseKey(i, p);
        }
        else if (func == 5)
        {
            cin >> i;
            cin >> p;
            max_heap.DecreaseKey(i, p);
        }
        else if (func == 6)
        {
            max_heap.print();
        }
        else
        {
            max_heap.Sort();
            max_heap.print();
        }
    }

    return 0;
}
