#include<iostream>
#include<string>
#include<fstream>
using namespace std;
class node
{
public:
    int data;
    node*left;
    node*right;

    node(int val)
    {
        data=val;
        left=nullptr;
        right=nullptr;
    }
};
    //node*root;
    node* insert(node*root,int val)
    {
        if(root==nullptr)
        {
            return new node(val);
        }
        else if(val>(root->data))root->right=insert(root->right,val);
        else root->left=insert(root->left,val);
        return root;
    }
    bool find(node*root,int val)
    {
        if(root==nullptr)return false;
        else if(root->data==val)return true;
        else if(val>root->data)find(root->right,val);
        else find(root->left,val);
    }
     void preorder(node*root){
    if(root==nullptr)return;
    cout<<root->data<<" ";
    preorder(root->left);
    preorder(root->right);
    }

    void inorder(node*root){
    if(root==nullptr)return;
    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
    }

    void postorder(node*root){
    if(root==nullptr)return;
    postorder(root->left);
    postorder(root->right);
    cout<<root->data<<" ";
    }

    node* minval(node*root){
    while(root->left!=nullptr){
        root=root->left;
    }
    return root;
    }


   node*delete_node(node*root,int val){
   if(root==nullptr)return root;
   else if(root->data==val){
    //0 child
    if(root->left==nullptr && root->right==nullptr){
        delete root;
        return nullptr;
    }
    //1 child
    //only left child is present
    else if(root->left!=nullptr && root->right==nullptr){
        node*temp=root->left;
        delete root;
        return temp;
    }
    //only right child is present
    else if(root->right!=nullptr && root->left==nullptr){
        node*temp=root->right;
        delete root;
        return temp;
    }
    //2 child
    else if(root->left!=nullptr && root->right!=nullptr){
        int min=minval(root->right)->data;
        root->data=min;
       root->right=delete_node(root->right,min);
       return root;
    }

   }
   else if(root->data > val){
   root->left=delete_node(root->left,val);
   return root;
   }

   else{
   root->right=delete_node(root->right,val);
   return root;
   }
   }
void print(node* root)
    {
        if (root == nullptr)
        {
            return;
        }
        cout << root->data;
        if (root->left != nullptr || root->right != nullptr)
        {
            cout << "(";
            print(root->left);
            cout << ",";
            print(root->right);
            cout << ")";
    }
}
int main()
{
    freopen("input1.txt", "r", stdin);
    freopen("output1.txt", "w", stdout);

    node* root = nullptr;
    while (!feof(stdin))
    {
        char func;
        int p;
        string type;
        cin >> func;
        if (feof(stdin))
            break;

        if (func == 'I')
        {
            cin >> p;
            root = insert(root, p);
            cout<<"(";
            print(root);
            cout<<")";
            cout<<endl;
        }
        else if (func == 'D')
        {
            cin >> p;
            root = delete_node(root, p);
            cout<<"(";
            print(root);
            cout<<")";
            cout<<endl;
        }
        else if (func == 'F')
        {
            cin >> p;
            if (find(root, p))
                cout << "found" << endl;
            else
                cout << "not found" << endl;
        }
        else if (func == 'T')
        {
            cin >> type;
            if (type == "In")
            {
                inorder(root);
                cout<<endl;
            }
            else if (type == "Pre")
            {
                preorder(root);
                cout<<endl;
            }
            else if (type == "Post")
            {
                postorder(root);
                cout<<endl;
            }
        }
    }
    return 0;
}
