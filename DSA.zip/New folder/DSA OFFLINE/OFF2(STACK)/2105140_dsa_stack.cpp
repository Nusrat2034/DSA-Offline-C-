#include <iostream>
#include<string>
using namespace std;
template<typename T>
class Stack {
private:
    int size;
    T* a;
    int top;

    void expand() {
        size = size * 2;
        T* newArr = new T[size];

        for (int i = 0; i < length(); i++) {
            newArr[i] = a[i];
        }
        delete[] a;
        a = newArr;
    }

public:
    Stack(int max_size) {
        size = max_size;
        top = -1;
        a = new T[size];
    }

    void clear() {
        delete[] a;
        top = -1;
    }

    ~Stack() {
        delete[] a;
    }

    void push(T n) {
        if (top == size) {
            expand();
        }
        a[++top] = n;
    }

    T pop() {
        if (top < 0) {
            return T();
        }
        return a[top--];
    }

    T topValue() {
        if (top < 0) {
            return T();
        }
        return a[top];
    }

    int length() {
        return top + 1;
    }

    bool isEmpty() {
        return (top==-1);
    }

    void print() {
        cout << "<";
        for (int i = 0; i <= top; i++) {
            cout << a[i]<<" ";
        }
        cout << ">";
    }
};

void choice(){
cout<<"0.quit"<<endl;
cout<<"1.clear"<<endl;
cout<<"2.push"<<endl;
cout<<"3.pop"<<endl;
cout<<"4.length"<<endl;
cout<<"5.topValue"<<endl;
cout<<"6.isEmpty"<<endl;
}
/*int main() {
    int x,k;
    cout<<"Enter the value of memory chunk size and initial length:";
    cin>>x>>k;
    cout<<"1.Integer type stack?"<<endl;
    cout<<"2.Character type stack?"<<endl;
    int n;
    cin>>n;
    switch(n){
    case 1:{
    Stack<int> intStack(x);
    cout<<"Enter elements:";
    for(int i=0;i<k;i++){
        int element;
        cin>>element;
        intStack.push(element);
    }
    intStack.print();
    choice();
    int c1;
    for(; ; ){
    cout<<"Enter your choice:";
    cin>>c1;
    switch(c1){
    case 1:{
    intStack.clear();
    intStack.print();
    cout<<endl;
    break;
    }
    case 2:{
    int item;
    cout<<"which item to push?";
    cin>>item;
    intStack.push(item);
    intStack.print();
    cout<<endl;
    break;
    }
    case 3:{
    cout<<"Returned value:"<<intStack.pop()<<endl;
    intStack.print();
    cout<<endl;
    break;
    }
    case 4:{
    cout<<"Returned value:"<<intStack.length()<<endl;
    intStack.print();
    cout<<endl;
    break;
    }
    case 5:{
    cout<<"Returned value:"<<intStack.topValue()<<endl;
    intStack.print();
    cout<<endl;
    break;
    }
    case 6:{
    if(intStack.isEmpty())cout<<"True"<<endl;
    else cout<<"False"<<endl;
    intStack.print();
    cout<<endl;
    break;
    }
    case 0:{
    exit(0);
    }
    }
    }
    }
    case 2:{
    Stack<char> charStack(x);
    cout<<"Enter elements:";
    for(int i=0;i<k;i++){
        char element;
        cin>>element;
        charStack.push(element);
    }
    charStack.print();
    choice();
    int c1;
    for(; ; ){
    cout<<"Enter your choice:";
    cin>>c1;
    switch(c1){
    case 1:{
    charStack.clear();
    charStack.print();
    cout<<endl;
    break;
    }
    case 2:{
    char item;
    cout<<"which item to push?";
    cin>>item;
    charStack.push(item);
    charStack.print();
    cout<<endl;
    break;
    }
    case 3:{
    cout<<"Returned value:"<<charStack.pop()<<endl;
    charStack.print();
    cout<<endl;
    break;
    }
    case 4:{
    cout<<"Returned value:"<<charStack.length()<<endl;
    charStack.print();
    cout<<endl;
    break;
    }
    case 5:{
    cout<<"Returned value:"<<charStack.topValue()<<endl;
    charStack.print();
    cout<<endl;
    break;
    }
    case 6:{
    if(charStack.isEmpty())cout<<"True"<<endl;
    else cout<<"False"<<endl;
    charStack.print();
    cout<<endl;
    break;
    }
    case 0:{
    exit(0);
    }
    }
    }
    }
    }
    return 0;
}*/
