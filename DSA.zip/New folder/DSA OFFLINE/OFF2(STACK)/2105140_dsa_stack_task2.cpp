#include <iostream>
#include <string>
#include<iomanip>
#include "2105140_dsa_stack.cpp"

using namespace std;

bool is_operator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

bool is_valid_expression(string& expression) {
    Stack<char> stack(expression.length());

    for (int i=0;expression[i]!='\0';i++) {
            char c=expression[i];
        if (c == '(') {
            stack.push(c);
        } else if (c == ')') {
            if (stack.isEmpty() || stack.topValue() != '(') {
                return false;
            }
            stack.pop();
        }
    }

    return stack.isEmpty();
}

int precedence(char optor) {
    if (optor == '+' || optor == '-') {
        return 1;
    } else if (optor == '*' || optor == '/') {
        return 2;
    } else if (optor == '%') {
        return 3;
    } else {
        return 0;
    }
}

float apply_operator(float val1, float val2, char op) {
    switch (op) {
        case '+':
            return val1 + val2;
        case '-':
            return val1 - val2;
        case '*':
            return val1 * val2;
        case '/':
            return val1 / val2;
        case '%':
            return (int)(val1) % (int)(val2);
        default:
            return 0;
    }
}

float evaluate_expression( string& expression) {
    if (!is_valid_expression(expression)) {
        cout << "Not valid" << endl;
        return 0;
    }

    Stack<char> op_stack(expression.length());
    Stack<float> val_stack(expression.length());

    for (int i = 0; i < expression.length(); ++i) {
        char c = expression[i];
        if (c == ' ') {
            continue; // Ignore whitespace
        } else if (c>='0' && c<='9') {
            string num_str;
            num_str += c;

            // Check if the next character is also a digit
            while (i + 1 < expression.length() && ((expression[i + 1]>='0' && expression[i+1]<='9'))){
                num_str += expression[i + 1];
                i++;
            }

        float value = stof(num_str);
        val_stack.push(value);
        }
        else if (c == '(') {
            op_stack.push(c);
        }
         else if (c == ')') {
            if (!op_stack.isEmpty() && op_stack.topValue() == '(') {
                op_stack.pop();
            }
            while (!op_stack.isEmpty() && op_stack.topValue() != '(') {
            char op = op_stack.pop();
            float val2 = val_stack.pop();
            float val1 = val_stack.pop();
            float result = apply_operator(val1, val2, op);
            val_stack.push(result);
            }
        }
        else if (is_operator(c)) {
            if (i > 0 && is_operator(expression[i - 1])) {
                // Invalid consecutive operators
                cout << "Not valid" << endl;
                return 0;
                }

            else if (c == '-' && (i == 0 || expression[i - 1] == '(')) {
                // Negative number
                string num_str;
                num_str += c;

                // Check if the next character is also a digit
                while (i + 1 < expression.length() && isdigit(expression[i + 1])) {
                    num_str += expression[i + 1];
                    i++;
                }

                float value = stof(num_str);
                val_stack.push(value);
            }
            else {
                while (!op_stack.isEmpty() && is_operator(op_stack.topValue()) &&
                       precedence(c) <= precedence(op_stack.topValue())) {
                    char op = op_stack.pop();
                    float val2 = val_stack.pop();
                    float val1 = val_stack.pop();
                    float result = apply_operator(val1, val2, op);
                    val_stack.push(result);
                }

                op_stack.push(c);
            }
        } else {
            cout << "Not valid" << endl;
            return 0;
        }
    }

    while (!op_stack.isEmpty()) {
        char op = op_stack.pop();
        float val2 = val_stack.pop();
        float val1 = val_stack.pop();
        float result = apply_operator(val1, val2, op);
        val_stack.push(result);
    }

    return val_stack.topValue();
}
int main() {
    //string expression = "(9*3-(7*8+((-4)/2)))";
    //string expression = "(9*3-(7*8+((4/2)))";
    //string expression = "6/3*2";
    string expression = "2+4/5*10/3";
    //string expression = "2++4";
    float result = evaluate_expression(expression);
    if (result != 0) {
        cout<<"Valid expression"<<endl;
        cout << "Computed value: " <<fixed<<setprecision(2)<< result << endl;
    }
    return 0;
}
