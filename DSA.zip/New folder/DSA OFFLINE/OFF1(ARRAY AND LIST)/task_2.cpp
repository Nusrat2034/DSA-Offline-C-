#include<iostream>
#include "Arr.cpp"
#include "LL.cpp"
using namespace std;
void append(ArrList& l, int val) {
    int n = l.currPos();
    l.moveToEnd();
    l.next();
    l.insert(val);
    l.moveToPos(n);
}

int Search(ArrList& L, int item) {
    int curr = L.currPos();
    for (L.moveToStart(); L.currPos() < L.length(); L.next()) {
        if (item == L.getValue()) {
            int n = L.currPos();
            L.moveToPos(curr);
            return n;
        }
    }
    return -1;
}

void clear(ArrList& L)
{
L.moveToStart();
int l=L.length();
 for (int i=0;i<l;i++) {
       L.remove();
       L.next();
    }
}

int Search(LinkedList& l, int item) {
    if (l.head == nullptr)
        return -1;
    else {
        LinkedList::node* temp = l.head;
        int i = 0;
        while (temp != nullptr) {
            if (temp->val == item)
                return i;
            else {
                i++;
                temp = temp->next;
            }
        }
    }
    return -1;
}

void clear(LinkedList& l) {
    while (l.head != nullptr) {
        LinkedList::node* temp = l.head;
        l.head = l.head->next;
        delete temp;
    }
}

void append(LinkedList& l, int value) {
    LinkedList::node* newnode = new LinkedList::node;
    newnode->val = value;
    newnode->next = nullptr;
    int n=l.currPos();
    l.moveToEnd();
    l.next();
    l.insert(value);
    l.moveToPos(n);
}
void choice(){
cout<<"1.Want to clear?"<<endl;
cout<<"2.Append item?"<<endl;
cout<<"3.Want to search?"<<endl;
}
int main(){
    ArrList a;
    LinkedList l;
for( ; ; ){
int Q;
cout<<"1.Array Based Implementation"<<endl;
cout<<"2.Linked List Based Implementation"<<endl;
cout<<"Which implement you want to do?"<<endl;
cin>>Q;
switch(Q){
case 0:{
exit(0);

}
case 1:
    {
        int x,k;
        cout<<"enter the value of x(maximum size of array) and k(initial size):"<<endl;
        cin>>x>>k;
        a.init(x,k);
        choice();
        a.print();
        cout<<endl;
        cout<<"Which task to do?"<<endl;
        int c1;
        cin>>c1;
        switch(c1)
        {
     case 1:
         {
             clear(a);
             a.print();
             cout<<endl;
             break;
         }
     case 2:
        {
         int item;
         cout<<"Which item to append?";
         cin>>item;
         append(a,item);
         a.print();
         cout<<endl;
         break;

        }
     case 3:
        {   int item;
            cout<<"Which item to search?";
            cin>>item;
            cout<<Search(a,item)<<endl;
            a.print();
            cout<<endl;
        }
     case 0:
        {
            exit(0);
        }
        }
    break;
    }
case 2:
    {
        cout<<"Enter size:";
        int k;
        cin>>k;
        l.init(k);
        choice();
        l.print();
        cout<<endl;
        cout<<"Which task to do?"<<endl;
        int c2;
        cin>>c2;
        switch(c2)
        {
     case 1:
         {
             clear(l);
             l.print();
             cout<<endl;
             break;
         }
     case 2:
        {
         int item;
         cout<<"Which item to append?";
         cin>>item;
         append(l,item);
         a.print();
         cout<<endl;
         break;

        }
     case 3:
        {   int item;
            cout<<"Which item to search?";
            cin>>item;
            cout<<Search(l,item)<<endl;
            l.print();
            cout<<endl;
        }
     case 0:
        {
            exit(0);
        }
        }
    break;
    }
}
}
return 0;
}
