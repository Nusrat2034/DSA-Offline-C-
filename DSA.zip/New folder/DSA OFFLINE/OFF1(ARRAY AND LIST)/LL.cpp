#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
class LinkedList
{

    int curr_pos;

public:


    struct node
    {
        int val;
        node* next;
    };

    node* head;

    LinkedList()
    {
        head=nullptr;
    }

    ~LinkedList()
    {

    }

    void init(int s)
    {
        curr_pos=rand()%s;
        for(int i=0; i<s; i++)
        {
            int n;
            cin>>n;
            node* newnode = new node;
            newnode->val = n;
            newnode->next = nullptr;

            if (head == nullptr)
            {
                head = newnode;
            }
            else
            {
                node* temp = head;
                while (temp->next != nullptr)
                {
                    temp = temp->next;
                }
                temp->next = newnode;
            }
        }
    }

    void insert(int item)
    {
        node* newnode=new node;
        newnode->val=item;
        int i=0;
        node*temp=head;
        while(i!=curr_pos-1)
        {
            temp=temp->next;
            i++;
        }
        newnode->next=temp->next;
        temp->next=newnode;
    }


    int remove()
    {
        int i=0;
        node* temp=head;
        while(i!=curr_pos-1)
        {
            temp=temp->next;
            i++;
        }
        node* todelete=temp->next;
        int n=temp->next->val;
        temp->next=temp->next->next;
        delete todelete;
        return n;
    }

    void moveToStart()
    {
        curr_pos=0;
    }

    void moveToEnd()
    {
        int i=0;
        node* temp=head;
        while(temp->next != nullptr)
        {
            temp=temp->next;
            i++;
        }
        curr_pos=i;
    }

    void prev()
    {

        curr_pos--;
    }

    void next()
    {
        curr_pos++;

    }

    int length()
    {
        int i=0;
        node* temp=head;
        while(temp->next !=nullptr)
        {
            temp=temp->next;
            i++;
        }
        return i+1;
    }

    int currPos()
    {
        return curr_pos;
    }

    void moveToPos(int pos)
    {
        curr_pos=pos;
    }

    int getValue()
    {
        int i=0;
        node* temp=head;
        while(i!=curr_pos)
        {
            temp=temp->next;
            i++;
        }
        return temp->val;
    }

    void print()
    {
        node*temp=head;
        cout<<"< ";
        int i=0;
        while(temp!= nullptr)
        {
            if(i==curr_pos) cout<<"|";
            cout<<temp->val<<" ";
            temp=temp->next;
            i++;

        }
        cout<<" >";
    }
};
