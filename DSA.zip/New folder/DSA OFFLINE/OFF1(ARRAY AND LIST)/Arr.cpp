#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
class ArrList
{
    int size;//maximum capacity of the list
    int* a;
    int curr_pos;
    int it;//for iterating through the whole list

public:
    ArrList()
    {
        a=new int[size];
        it=0;
    }

    void init(int max_len,int s)
    {
        size=max_len;
        a=new int[size];
        curr_pos=rand()%s;
        for(int i=0; i<s; i++)
        {
            cin>>a[i];
            it++;
        }
    }


    ~ArrList()
    {
        delete[]a;
    }



    int currPos()
    {
        return curr_pos;
    }


    void insert(int n)
    {
        if(it==size)
        {
            int* new_a=new int[2*size];
            for(int i=0; i<size; i++)
            {
                new_a[i]=a[i];
            }
            delete[]a;
            a=new_a;
            size=2*size;
        }
        for(int i=it-1; i>=currPos(); i--)
        {
            a[i+1]=a[i];
        }
        a[curr_pos]=n;
        it++;
    }



    int remove()
    {
        if(a!=NULL)
        {
            int n=a[currPos()];
            for(int i=currPos(); i<it-1; i++)
            {
                a[i]=a[i+1];
            }
            it--;
            return n;
        }
    }



    void moveToStart()
    {
        if(curr_pos!=0)
            curr_pos=0;
        else currPos();
    }


    void moveToEnd()
    {
        if(curr_pos!=it-1)
            curr_pos=it-1;
        else currPos();
    }


    void prev()
    {
        if(curr_pos!=0)
            curr_pos--;
        else return;
    }


    void next()
    {
        if(curr_pos!=it)
            curr_pos++;
        else return;
    }

    int length()
    {

        return it;
    }

   void  moveToPos(int pos)
    {

        curr_pos=pos;
    }


    int getValue()
    {

        return(a[currPos()]);
    }

    void print()
    {
        if(a!=nullptr)
        {
            cout<<"< ";
            for(int i=0; i<it; i++)
            {
                if(i==curr_pos)cout<<"|";
                cout<<a[i]<<" ";
            }
            cout<<" >";
        }
        else return;
    }

};
