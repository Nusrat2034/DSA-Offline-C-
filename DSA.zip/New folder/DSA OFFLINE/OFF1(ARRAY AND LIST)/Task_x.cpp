#include<iostream>
#include<cstring>
#include "Arr.cpp"
#include "LL.cpp"
using namespace std;
class CRS
{
    int number_of_cars;
    int number_of_garages;
    int max_in_garage;
    ArrList* g1;/*onekgulo arraylist ba list niye arekta
               array g1 or g2 design kori jeta garage remark kore*/
    LinkedList* g2;//for linkedlist implementation

public:
    CRS(int c, int g, int mg, ArrList*al)
    {
        number_of_cars = c;
        number_of_garages = g;
        max_in_garage = mg;
        g1 = new ArrList[number_of_garages];
        for (int i = 0; i < number_of_garages; i++)
        {
            int level;
            int num_car;
            cin>>level>>num_car;
            g1[level-1] = al[level-1];
            g1[level-1].init(number_of_cars,num_car);
        }
    }

    CRS(int c, int g, int mg, LinkedList*ll)
    {
        number_of_cars = c;
        number_of_garages = g;
        max_in_garage = mg;
        g2 = new LinkedList[number_of_garages];
        for (int i = 0; i < number_of_garages; i++)
        {
            int level;
            int num_car;
            cin>>level>>num_car;
            g2[level-1] = ll[level-1];
            g2[level-1].init(num_car);
        }
    }
    void req( ArrList*al)
    {
        for(int i=0; i<number_of_garages; i++)
        {
            if(g1[i].length()!=0)
            {
                g1[i].moveToStart();
                int n=g1[i].getValue();
                int position=g1[i].currPos();
                for(int j=g1[i].currPos(); j<g1[i].length(); j++)
                {
                    if(g1[i].getValue()<n)
                    {
                        n=g1[i].getValue();
                        position=g1[i].currPos();
                        g1[i].next();
                    }
                    else
                    {
                        g1[i].next();
                    }
                }
                g1[i].moveToPos(position);
                cout<<"Requesting the car number: "<< g1[i].remove()<<endl;
                return;
            }
        }
        cout<<"All garages are empty!"<<endl;
    }

    void ret(ArrList*al,int car)
    {
        for(int i=number_of_garages-1; i>=0; i--)
        {
            if(g1[i].length()<max_in_garage)
            {
                g1[i].moveToStart();
                int n=g1[i].getValue();
                int position=g1[i].currPos();
                for(int j=g1[i].currPos(); j<g1[i].length(); j++)
                {
                    if(g1[i].getValue()>n)
                    {
                        n=g1[i].getValue();
                        position=g1[i].currPos();
                        g1[i].next();
                    }
                    else
                    {
                        g1[i].next();
                    }
                }
                g1[i].moveToPos(position);
                g1[i].next();
                g1[i].insert(car);
                cout<<"Returning the car number: "<< car<<endl;
                return;
            }
        }
        cout<<"All garages are full!"<<endl;
    }

    void req( LinkedList* ll)
    {
        for(int i=0; i<number_of_garages; i++)
        {
            if(g2[i].length()!=0)
            {
                g2[i].moveToStart();
                int n=g2[i].getValue();
                int position=g2[i].currPos();
                for(int j=g2[i].currPos(); j<g2[i].length(); j++)
                {
                    if(g2[i].getValue()<n)
                    {
                        n=g2[i].getValue();
                        position=g2[i].currPos();
                        g2[i].next();
                    }
                    else
                    {
                        g2[i].next();
                    }
                }
                g2[i].moveToPos(position);
                cout<<"Requesting the car number: "<< g2[i].remove()<<endl;
                return;
            }
        }
        cout<<"All garages are empty!"<<endl;
    }

    void ret(LinkedList* ll, int car)
    {
        for(int i=number_of_garages-1; i>=0; i--)
        {
            if(g2[i].length()<max_in_garage)
            {
                g2[i].moveToStart();
                int n=g2[i].getValue();
                int position=g2[i].currPos();
                for(int j=g2[i].currPos(); j<g2[i].length(); j++)
                {
                    if(g2[i].getValue()>n)
                    {
                        n=g2[i].getValue();
                        position=g2[i].currPos();
                        g2[i].next();
                    }
                    else
                    {
                        g2[i].next();
                    }
                }
                g2[i].moveToPos(position);
                g2[i].next();
                g2[i].insert(car);
                cout<<"Returning the car number: "<< car << endl;
                return;
            }
        }
        cout<<"All garages are full!"<<endl;
    }

    ~CRS()
    {
        if(g1!=nullptr)delete[]g1;
        else if(g2!=nullptr)delete[]g2;
    }

    void print(ArrList*al)
    {
        for(int i=0; i<number_of_garages; i++)
        {
            cout<<"Garage->"<<i+1<<" : ";
            g1[i].moveToStart();
            for(int j=0; j<g1[i].length(); j++)
            {
                cout<<g1[i].getValue()<<" ";
                g1[i].next();
            }
            cout<<endl;
        }
    }

    void print(LinkedList* ll)
    {
        for(int i = 0; i < number_of_garages; i++)
        {
            cout << "Garage->" << i+1 << " : ";
            g2[i].moveToStart();
            for(int j = 0; j < g2[i].length(); j++)
            {
                cout << g2[i].getValue() << " ";
                g2[i].next();
            }
            cout << endl;
        }
    }

};

int main()
{
    int num_cars,num_gars,num_max_car;
    cout<<"Number of cars you have: ";
    cin>>num_cars;
    cout<<"Number of garages you have: ";
    cin>>num_gars;
    cout<<"Maximum number of cars in any garage: ";
    cin>>num_max_car;
    char str_req[10]="req";
    char str_ret[10]="ret";
    char str_end[10]="end";
    char str[10];
    ArrList* al=new ArrList[num_gars];
    CRS s1(num_cars,num_gars,num_max_car,al);
    s1.print(al);
    while(1)
    {
        cin>>str;
        if(!(strcmp(str,str_req)))
        {
            s1.req(al);
            s1.print(al);
        }
        else if(!(strcmp(str,str_ret)))
        {
            int car_level;
            cin>>car_level;
            s1.ret(al,car_level);
            s1.print(al);
        }
        else if(!(strcmp(str,str_end)))
        {
            return 0;
        }
    }

    /*LinkedList* ll=new LinkedList[num_gars];
     CRS s2(num_cars,num_gars,num_max_car,ll);
     s2.print(ll);
     while(1)
     {
         cin>>str;
         if(!(strcmp(str,str_req)))
         {
         s2.req(ll);
         s2.print(ll);
         }
         else if(!(strcmp(str,str_ret)))
         {
             int car_level;
             cin>>car_level;
             s2.ret(ll,car_level);
             s2.print(ll);
         }
         else if(!(strcmp(str,str_end)))
         {
             return 0;
         }
     }*/
    return 0;
}
