#include<iostream>
#include "Arr.cpp"
#include "LL.cpp"
using namespace std;
int main()
{
    cout<<"1.Array based implementation?"<<endl;
    cout<<"2.Linked List based implementation?"<<endl;
    int choice;
    cin>>choice;
    switch(choice)
    {
    case 1:
    {
        ArrList a;
        int Q,P;
        int X,K; //k is the initial length and
        // X is the maximum size
        cout<<"Enter the value of X(maximum size) and K(initial length) : ";
        cin>>X>>K;
        a.init(X,K);
        a.print();
        cout<<endl;
        cout<<"1.Insert item at current position?"<<endl;
        cout<<"2.Remove item from current position?"<<endl;
        cout<<"3.Move to start?"<<endl;
        cout<<"4.Move to end?"<<endl;
        cout<<"5.Go to previous?"<<endl;
        cout<<"6.Go to next?"<<endl;
        cout<<"7.Want to know the length of list?"<<endl;
        cout<<"8.Return your current position."<<endl;
        cout<<"9.Move to any position?"<<endl;
        cout<<"10.Get the value of current position?"<<endl;
        for( ; ; )
        {
            cout<<"Enter your question: ";
            cin>>Q;
            switch(Q)
            {
            case 0:
            {
                exit(0);
            }
            case 1:
            {
                cout<<"Enter the item you want to insert:";
                cin>>P;
                a.insert(P);
                a.print();
                cout<<endl;
                cout<<"Return value: -1"<<endl;
                break;
            }
            case 2:
            {
                cout<<"Return value: "<<a.remove()<<endl;
                a.print();
                cout<<endl;
                break;
            }

            case 3:
            {
                a.moveToStart();
                cout<<"Return value: -1"<<endl;
                a.print();
                cout<<endl;
                break;
            }
            case 4:
            {
                a.moveToEnd();
                cout<<"Return value: -1"<<endl;
                a.print();
                cout<<endl;
                break;
            }
            case 5:
            {
                a.prev();
                cout<<"Return value: -1"<<endl;
                a.print();
                cout<<endl;
                break;
            }
            case 6:
            {
                a.next();
                cout<<"Return value: -1"<<endl;
                a.print();
                cout<<endl;
                break;
            }

            case 7:
            {
                cout<<"Return value: "<<a.length()<<endl;
                a.print();
                cout<<endl;
                break;
            }
            case 8:
            {
                cout<<"Return value: "<<a.currPos()<<endl;
                a.print();
                cout<<endl;
                break;
            }
            case 9:
            {
                int n;
                cout<<"Enter the position you want to move to:";
                cin>>n;
                a.moveToPos(n);
                a.print();
                cout<<endl;
                cout<<"Return value: -1"<<endl;
                break;
            }
            case 10:
            {
                cout<<"Return value:"<<a.getValue()<<endl;
                a.print();
                cout<<endl;
                break;
            }
            }
        }
    }
    case 2:
    {
        LinkedList a;
        int Q,P;
        int k;
        cout<<"Enter the value of K:";
        cin>>k;
        a.init(k);
        a.print();
        cout<<endl;
        cout<<"1.Insert item at current position?"<<endl;
        cout<<"2.Remove item from current position?"<<endl;
        cout<<"3.Move to start?"<<endl;
        cout<<"4.Move to end?"<<endl;
        cout<<"5.Go to previous?"<<endl;
        cout<<"6.Go to next?"<<endl;
        cout<<"7.Want to know the length of list?"<<endl;
        cout<<"8.Return your current position."<<endl;
        cout<<"9.Move to any position?"<<endl;
        cout<<"10.Get the value of current position?"<<endl;
        for( ; ; )
        {
            cout<<"Enter your question: ";
            cin>>Q;
            switch(Q)
            {
            case 0:
            {
                exit(0);
            }
            case 1:
            {
                cout<<"Enter the item you want to insert:";
                cin>>P;
                a.insert(P);
                a.print();
                cout<<"Return value: -1"<<endl;
                break;
            }
            case 2:
            {
                cout<<"Return value: "<<a.remove()<<endl;
                a.print();
                cout<<endl;
                break;
            }

            case 3:
            {
                a.moveToStart();
                a.print();
                cout<<"Return value: -1"<<endl;
                break;
            }
            case 4:
            {
                a.moveToEnd();
                a.print();
                cout<<"Return value: -1"<<endl;
                break;
            }
            case 5:
            {
                a.prev();
                a.print();
                cout<<"Return value: -1"<<endl;
                break;
            }
            case 6:
            {
                a.next();
                a.print();
                cout<<"Return value: -1"<<endl;
                break;
            }

            case 7:
            {
                cout<<"Return value: "<<a.length()<<endl;
                a.print();
                cout<<endl;
                break;
            }
            case 8:
            {
                cout<<"Return value: "<<a.currPos()<<endl;
                a.print();
                cout<<endl;
                break;
            }
            case 9:
            {
                int n;
                cout<<"Enter the position you want to move to:";
                cin>>n;
                a.moveToPos(n);
                cout<<"Return value: -1"<<endl;
                a.print();
                cout<<endl;
                break;
            }
            case 10:
            {
                cout<<"Return value: "<<a.getValue()<<endl;
                a.print();
                cout<<endl;
                break;
            }
            }
        }
    }
    }
    return 0;
}
