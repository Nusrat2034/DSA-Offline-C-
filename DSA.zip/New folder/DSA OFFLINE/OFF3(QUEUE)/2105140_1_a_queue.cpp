#include<iostream>
#include "2105140_1_a_queue.h"
using namespace std;
template <class T>
class queue_arr{
int size;
ArrList <T> al;
public:
    queue_arr(int s):al(s){}

    void enqueue(T item){
        al.insert(item);
    }
    T dequeue(){
    T temp=al.remove();
    return temp;
    }
    int length(){
    return al.length();
    }
    T front(){
    al.moveToStart();
    return al.getValue();
    }
    T back(){
    al.moveToEnd();
    return al.getValue();
    }
    bool is_empty(){
    if(!al.length())return true;
    else return false;
    }
    void clear() {
    al.moveToStart();
   int l=al.length();
   for (int i=0;i<l;i++) {
    al.remove();
    al.next();
    }
   }
    void print(){
        al.print();
    }
};
