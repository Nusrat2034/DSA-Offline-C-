#include<iostream>
#include"2105140_1_ll_queue.h"
using namespace std;

template <class T>
class queue_ll{
LinkedList<T> l;
public:
    void enqueue(T item){
        l.insert(item);
    }
    T dequeue(){
    T temp=l.remove();
    return temp;
    }
    int length(){
    return l.length();
    }
    T front(){
    l.moveToStart();
    return l.getValue();
    }
    T back(){
    l.moveToEnd();
    return l.getValue();
    }
    bool is_empty(){
    if(!l.length())return true;
    else return false;
    }
    void clear() {
    while (l.head != nullptr) {
      node<T>* temp = l.head;
        l.head = l.head->next;
        delete temp;
    }
  }
    void print(){
        l.print();
    }
};
