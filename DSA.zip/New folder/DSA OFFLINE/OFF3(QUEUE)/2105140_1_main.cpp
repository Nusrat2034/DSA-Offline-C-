#include<iostream>
#include "2105140_1_ll_queue.cpp"
#include "2105140_1_a_queue.cpp"
using namespace std;
void function_choice(){
cout<<"0.exit"<<endl;
cout<<"1.enqueue"<<endl;
cout<<"2.dequeue"<<endl;
cout<<"3.length"<<endl;
cout<<"4.front"<<endl;
cout<<"5.back"<<endl;
cout<<"6.is_empty"<<endl;
cout<<"7.clear"<<endl;
}
void data_type_choice(){
cout<<"1.int"<<endl;
cout<<"2.char"<<endl;
}
void implement_choice(){
cout<<"1.Linked list base implementation"<<endl;
cout<<"2.Circular array based implementation"<<endl;
}
int main(){
implement_choice();
int ic;
cin>>ic;
switch(ic){
case 1:{
cout<<"Which data type you want to implement?"<<endl;
data_type_choice();
int choice;
cin>>choice;
switch(choice){
    case 1:{
    queue_ll<int>q1;
    while(1){
    function_choice();
    cout<<"Enter your function choice:";
    int c;
    cin>>c;
    switch(c){
    case 0:{
    exit(0);
    }
    case 1:{
    cout<<"How many elements to enqueue:";
    int b;
    cin>>b;
    cout<<"Enter elements:";
    for(int i=0;i<b;i++){
    int p;
    cin>>p;
    q1.enqueue(p);
    }
    q1.print();
    cout<<endl;
    cout<<"Return value:-1"<<endl;
    break;
    }
    case 2:{
    int ret=q1.dequeue();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 3:{
    int ret=q1.length();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 4:{
    int ret=q1.front();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 5:{
    int ret=q1.back();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 6:{
    int ret=q1.is_empty();
    q1.print();
    cout<<endl;
    if(ret)cout<<"True"<<endl;
    else cout<<"False"<<endl;
    break;
    }
    case 7:{
    q1.clear();
    q1.print();
    cout<<endl;
    cout<<"Return value:-1"<<endl;
    break;
    }
    }
    }
  }
  case 2:{
    queue_ll<char>q1;
    while(1){
    function_choice();
    cout<<"Enter your function choice:";
    int c;
    cin>>c;
    switch(c){
    case 0:{
    exit(0);
    }
    case 1:{
    cout<<"How many elements to enqueue:";
    int b;
    cin>>b;
    cout<<"Enter elements:";
    for(int i=0;i<b;i++){
    char p;
    cin>>p;
    q1.enqueue(p);
    }
    q1.print();
    cout<<endl;
    cout<<"Return value:-1"<<endl;
    break;
    }
    case 2:{
    char ret=q1.dequeue();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 3:{
    char ret=q1.length();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 4:{
    char ret=q1.front();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 5:{
    char ret=q1.back();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 6:{
    int ret=q1.is_empty();
    q1.print();
    cout<<endl;
    if(ret)cout<<"True"<<endl;
    else cout<<"False"<<endl;
    break;
    }
    case 7:{
    q1.clear();
    q1.print();
    cout<<endl;
    cout<<"Return value:-1"<<endl;
    break;
    }
    }
    }
  }
}
}
case 2:{
cout<<"Which data type you want to implement?"<<endl;
data_type_choice();
int choice;
cin>>choice;
switch(choice){
    case 1:{
    int s;
    cout<<"Enter the size of queue for array implementation:";
    cin>>s;
    queue_arr<int>q1(s);
    while(1){
    function_choice();
    cout<<"Enter your function choice:";
    int c;
    cin>>c;
    switch(c){
    case 0:{
    exit(0);
    }
    case 1:{
    cout<<"How many elements to enqueue:";
    int b;
    cin>>b;
    cout<<"Enter elements:";
    for(int i=0;i<b;i++){
    int p;
    cin>>p;
    q1.enqueue(p);
    }
    q1.print();
    cout<<endl;
    cout<<"Return value:-1"<<endl;
    break;
    }
    case 2:{
    int ret=q1.dequeue();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 3:{
    int ret=q1.length();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 4:{
    int ret=q1.front();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 5:{
    int ret=q1.back();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 6:{
    int ret=q1.is_empty();
    q1.print();
    cout<<endl;
    if(ret)cout<<"True"<<endl;
    else cout<<"False"<<endl;
    break;
    }
    case 7:{
    q1.clear();
    q1.print();
    cout<<endl;
    cout<<"Return value:-1"<<endl;
    break;
    }
    }
    }
  }
  case 2:{
    int s;
    cout<<"Enter the size of queue for array implementation:";
    cin>>s;
    queue_arr<char>q1(s);
    while(1){
    function_choice();
    cout<<"Enter your function choice:";
    int c;
    cin>>c;
    switch(c){
    case 0:{
    exit(0);
    }
    case 1:{
    cout<<"How many elements to enqueue:";
    int b;
    cin>>b;
    cout<<"Enter elements:";
    for(int i=0;i<b;i++){
    char p;
    cin>>p;
    q1.enqueue(p);
    }
    q1.print();
    cout<<endl;
    cout<<"Return value:-1"<<endl;
    break;
    }
    case 2:{
    char ret=q1.dequeue();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 3:{
    char ret=q1.length();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 4:{
    char ret=q1.front();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 5:{
    char ret=q1.back();
    q1.print();
    cout<<endl;
    cout<<"Return value:"<<ret<<endl;
    break;
    }
    case 6:{
    int ret=q1.is_empty();
    q1.print();
    cout<<endl;
    if(ret)cout<<"True"<<endl;
    else cout<<"False"<<endl;
    break;
    }
    case 7:{
    q1.clear();
    q1.print();
    cout<<endl;
    cout<<"Return value:-1"<<endl;
    break;
    }
    }
    }
  }
}
}
}
return 0;
}
