#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
template<class T>
class node
{
public:
T val;
node* next;
node(){
val=T();
next=nullptr;
}
};

template<class T>
class LinkedList
{
    int s;
    int curr_pos;

public:
    node<T>* head;

    LinkedList()
    {
        head=nullptr;
        curr_pos=0;
        s=0;
    }

    ~LinkedList()
    {

    }

    void insert(T item)
    {
        node<T>* newnode=new node<T>;
        newnode->val=item;
        if(head==nullptr){
        head=newnode;
        s++;
        curr_pos++;
        }
        else{
        node<T>*temp=head;
        while(temp->next!=nullptr)
        {
            temp=temp->next;
        }
        temp->next=newnode;
        s++;
        curr_pos++;
        }
    }


    T remove()
    {
        node<T>* temp=head;
        node<T>* todelete=temp;
        T n=temp->val;
        head=head->next;
        delete todelete;
        s--;
        return n;
    }

    void moveToStart()
    {
        curr_pos=0;
    }

    void moveToEnd()
    {
        int i=0;
        node<T>* temp=head;
        while(temp->next != nullptr)
        {
            temp=temp->next;
            i++;
        }
        curr_pos=i;
    }

    void prev()
    {

        curr_pos--;
    }

    void next()
    {
        curr_pos++;

    }

    int length()
    {
    return s;
    }

    int currPos()
    {
        return curr_pos;
    }

    void moveToPos(int pos)
    {
        curr_pos=pos;
    }

    T getValue()
    {
        int i=0;
        node<T>* temp=head;
        while(i!=curr_pos)
        {
            temp=temp->next;
            i++;
        }
        return temp->val;
    }

    void print()
    {
        node<T>*temp=head;
        cout<<"< ";
        int i=0;
        while(temp!= nullptr)
        {
            cout<<temp->val<<" ";
            temp=temp->next;
            i++;

        }
        cout<<" >";
    }
};
