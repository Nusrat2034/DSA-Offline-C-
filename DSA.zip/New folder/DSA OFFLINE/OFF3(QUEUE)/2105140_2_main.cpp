#include<iostream>
#include"2105140_2_stack.h"
void function_choice(){
cout<<"0.exit"<<endl;
cout<<"1.clear"<<endl;
cout<<"2.push"<<endl;
cout<<"3.pop"<<endl;
cout<<"4.length"<<endl;
cout<<"5.topValue"<<endl;
cout<<"6.isEmpty"<<endl;
}
void data_type_choice(){
cout<<"1.int"<<endl;
cout<<"2.char"<<endl;
cout<<"3.double"<<endl;
}
int main(){
data_type_choice();
int c;
cin>>c;
switch(c){
case 1:{
cout<<"Enter size of stack:";
int s;
cin>>s;
Stack<int>st(s);
while(1){
function_choice();
int ch;
cin>>ch;
switch(ch){
case 0:{
exit(0);
break;
}
case 1:{
st.clear();
st.print();
cout<<endl;
break;
}
case 2:{
cout<<"Which item to push?";
int p;
cin>>p;
st.push(p);
st.print();
cout<<endl;
cout<<"Returned Value:-1"<<endl;
break;
}
case 3:{
int p;
p=st.pop();
st.print();
cout<<endl;
cout<<"Returned Value:"<<p<<endl;
break;
}
case 4:{
int p;
p=st.length();
st.print();
cout<<endl;
cout<<"Returned Value:"<<p<<endl;
break;
}
case 5:{
int p;
p=st.topValue();
st.print();
cout<<endl;
cout<<"Returned Value:"<<p<<endl;
break;
}
case 6:{
if(st.isEmpty())cout<<"True"<<endl;
else cout<<"False"<<endl;
break;
}
}
}
}
case 2:{
cout<<"Enter size of stack:";
int s;
cin>>s;
Stack<char>st(s);
while(1){
function_choice();
int ch;
cin>>ch;
switch(ch){
case 0:{
exit(0);
break;
}
case 1:{
st.clear();
st.print();
cout<<endl;
break;
}
case 2:{
cout<<"Which item to push?";
char p;
cin>>p;
st.push(p);
st.print();
cout<<endl;
cout<<"Returned Value:-1"<<endl;
break;
}
case 3:{
char p;
p=st.pop();
st.print();
cout<<endl;
cout<<"Returned Value:"<<p<<endl;
break;
}
case 4:{
int p;
p=st.length();
st.print();
cout<<endl;
cout<<"Returned Value:"<<p<<endl;
break;
}
case 5:{
char p;
p=st.topValue();
st.print();
cout<<endl;
cout<<"Returned Value:"<<p<<endl;
break;
}
case 6:{
if(st.isEmpty())cout<<"True"<<endl;
else cout<<"False"<<endl;
break;
}
}
}
}
case 3:{
cout<<"Enter size of stack:";
int s;
cin>>s;
Stack<double>st(s);
while(1){
function_choice();
int ch;
cin>>ch;
switch(ch){
case 0:{
exit(0);
break;
}
case 1:{
st.clear();
st.print();
cout<<endl;
break;
}
case 2:{
cout<<"Which item to push?";
double p;
cin>>p;
st.push(p);
st.print();
cout<<endl;
cout<<"Returned Value:-1"<<endl;
break;
}
case 3:{
double p;
p=st.pop();
st.print();
cout<<"Returned Value:"<<p<<endl;
break;
}
case 4:{
int p;
p=st.length();
st.print();
cout<<"Returned Value:"<<p<<endl;
break;
}
case 5:{
double p;
p=st.topValue();
st.print();
cout<<"Returned Value:"<<p<<endl;
break;
}
case 6:{
if(st.isEmpty())cout<<"True"<<endl;
else cout<<"False"<<endl;
break;
}
}
}
}
}
return 0;
}
