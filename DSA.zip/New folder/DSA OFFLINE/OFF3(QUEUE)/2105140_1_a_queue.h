#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
template<class T>
class ArrList
{
    int curr_pos;
    int size;//maximum capacity of the list
    T* a;
    int front;
    int rear;//for iterating through the whole list

public:
    ArrList(int s)
    {
        front=rear=-1;
        curr_pos=0;
        size=s;
        a=new T[size];
    }

    ~ArrList()
    {
        delete[]a;
    }

    int currPos()
    {
        return curr_pos;
    }


    void insert(T n)
    {
        if((front==0 && rear==size-1)||
                (rear+1)%size==front)
        {
            cout<<"Overflow"<<endl;
            return;
        }
        else if(front==-1)
        {
            front=rear=0;
            a[rear]=n;
        }
        else if(rear==size-1 && front!=0)
        {
            rear=0;
            a[rear]=n;
        }
        else
        {
            rear++;
            a[rear]=n;
        }
    }

    T remove()
    {
        if(front==-1)
        {
            cout<<"Empty !"<<endl;
            return -1;
        }
        int data=a[front];
        a[front]=-1;
        if(front==rear)
        {
            front=-1;
            rear=-1;
        }
        else if(front==size-1 || front==rear )front=0;
        else front++;
        return data;
    }

    void moveToStart()
    {
        if(curr_pos!=front)
            curr_pos=front;
        else currPos();
    }

    void moveToEnd()
    {
        if(curr_pos!=rear)
            curr_pos=rear;
        else currPos();
    }

    void prev()
    {
        if(curr_pos!=front)
            curr_pos--;
        else return;
    }

    void next()
    {
        if(curr_pos!=rear)
            curr_pos++;
        else return;
    }

    int length()
    {
        if (front == -1)
            return 0;

        if (rear >= front)
            return (rear - front + 1);
        else
            return (size - front + rear + 1);
    }

    void moveToPos(int pos)
    {
        curr_pos=pos;
    }

    T getValue()
    {
        return(a[currPos()]);
    }

void print()
{
    if (rear == -1)
    {
        cout << "< >";
        return;
    }

    cout << "< ";
    if (rear >= front)
    {
        for (int i = front; i <= rear; i++)
        {
            cout << a[i] << " ";
        }
    }
    else
    {
        for (int i = front; i < size; i++)
        {
            cout << a[i] << " ";
        }
        for (int i = 0; i <= rear; i++)
        {
            cout << a[i] << " ";
        }
    }
    cout << ">";
}

};
