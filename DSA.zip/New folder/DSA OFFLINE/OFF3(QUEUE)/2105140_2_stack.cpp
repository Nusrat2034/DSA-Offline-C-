#include<iostream>
#include"2105140_1_a_queue.cpp"
template<class T>
class Stack {
    int n;
    queue_arr<T>q1;
    queue_arr<T>q2;
public:
     Stack(int s) : q1(s), q2(s) {}

    void push(T x){
    q1.enqueue(x);
    }

    T pop() {
        while(q1.length()!=1){
            q2.enqueue(q1.front());
            q1.dequeue();
        }
        T r= q1.front();
        q1.dequeue();
        while(!q2.is_empty()){
            q1.enqueue(q2.front());
            q2.dequeue();
        }
        return r;
    }

    T topValue() {
    return q1.back();
    }
    int length(){
    return q1.length();
    }
    void clear(){
    q1.clear();
    }
    bool isEmpty() {
    if(q1.is_empty())return true;
    else return false;
    }
    void print(){
    q1.print();
    }
};
