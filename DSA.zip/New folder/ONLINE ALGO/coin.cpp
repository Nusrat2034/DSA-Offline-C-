#include <iostream>
#include <vector>
#include <climits>

using namespace std;

int minNotesToPay(int V, const vector<int>& notes) {
    int n = notes.size();
    vector<int> dp(V + 1, INT_MAX);
    dp[0] = 0;

    for (int note : notes) {
        for (int amount = note; amount <= V; ++amount) {
            if (dp[amount - note] != INT_MAX) {
                dp[amount] = min(dp[amount], dp[amount - note] + 1);
            }
        }
    }

    return dp[V];
}

int main() {
    cout<<"enter the number of coins:";
    int n;
    cin >> n;
    vector<int> notes(n);
    cout<<"enter coins value:";
    for (int i = 0; i < n; ++i) {
        cin >> notes[i];
    }
    cout<<"enter amount:";
    int V;
    cin >> V;

    int result = minNotesToPay(V, notes);
    cout << "Minimum number of notes to pay " << V << " is " << result << endl;

    return 0;
}
