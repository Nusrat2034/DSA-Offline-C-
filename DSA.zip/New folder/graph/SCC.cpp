#include<bits/stdc++.h>
#include <iostream>
using namespace std;

class SAT
{
public:
    int n;
    unordered_map<string, vector<string>> graph;
    unordered_map<string, vector<string>> reversed_graph;
    vector<vector<string>> allscc;
    unordered_map<string, bool> visited;
    unordered_map<char, bool> variableVisited;
    unordered_map<char, bool> assignvar;
    unordered_map<string, bool> visited2;
    stack<string> dfsStack;
    vector<string>revtopo;
    SAT(int numVariables)
    {
        n = numVariables;
    }

    void addEdge(string x)
    {
        graph[x].push_back(negate(x));
        reversed_graph[negate(x)].push_back(x);
    }

    void addEdge(string x, string y)
    {
        graph[x].push_back(negate(y));
        reversed_graph[negate(y)].push_back(x);
        graph[negate(x)].push_back(y);
        reversed_graph[negate(y)].push_back(x);
    }

    string negate(string x)
    {
        if (x[0] == '~') return x.substr(1);
        else return ("~" + x);
    }

    void dfs(string node)
    {
        visited[node] = true;
        for (string neighbor : graph[node])
        {
            if (!visited[neighbor])
            {
                dfs(neighbor);
            }
        }
        dfsStack.push(node);
    }

    void reverseDfs(string node, vector<string>& scc)
    {
        visited2[node] = true;
        scc.push_back(node);
        for (string neighbor : reversed_graph[node])
        {
            if (!visited2[neighbor])
            {
                reverseDfs(neighbor, scc);
            }
        }
    }
    bool contradiction(vector<string>& y, int i) {
    string x = y[i];
    for (int k = 0; k < y.size(); k++) {
        if (x == negate(y[k])) return true;
    }
    return false;
   }

    bool isSatisfiable()
    {
        for (auto k : graph)
        {
            string source = k.first;
            if (!visited[source])
            {
                dfs(source);
            }
        }

        while (!dfsStack.empty())
        {
            string node = dfsStack.top();
            dfsStack.pop();
            revtopo.push_back(node);
            if (!visited2[node])
            {
                vector<string>scc;
                reverseDfs(node, scc);
                allscc.push_back(scc);
            }
        }
        for (int i = 0; i < allscc.size(); i++) {
        vector<string> y =allscc[i];
        for (int j = 0; j < y.size(); j++) {
            if (contradiction(y, j)) return false;
            else continue;
        }

        }
      return true;
        }

    void print()
    {
        if(!isSatisfiable())
        {
            cout<<"No assignment possible."<<endl;
            return;
        }
        reverse(revtopo.begin(), revtopo.end());
        for(int i=0;i<revtopo.size();i++){
         char c;
         string s=revtopo[i];
         if(s[0]=='~'){
         c=s[1];
         if(!variableVisited[c]) assignvar[c]=false;
         }
         else{
            char c=s[0];
            if(!variableVisited[c]) assignvar[c]=true;
         }
        }
        for(auto entry:assignvar)
        {
            cout<<entry.first<<" "<<(entry.second ? "True":"False")<<endl;
        }
    }
};
int main()
{
    freopen("sccinput.txt", "r", stdin);
    freopen("sccoutput.txt", "w", stdout);

    string line;
    while (!feof(stdin))
    {
        char p;
        cin>> p;
        if (feof(stdin))
            break;
        if (p == 'S')
        {
            int n;
            cin >> n;
            SAT solve(n);
            //cin.ignore();
            for (int i = 0; i < n; i++)
            {
                getline(cin, line);
                if (line.empty())
                {
                    i--;
                    continue;
                }
                if (line.find(' ') == string::npos)
                {
                    string literal = line;
                    solve.addEdge(literal);

                }
                else
                {
                    size_t spacePos = line.find(' ');
                    string literal1 = line.substr(0, spacePos);
                    string literal2 = line.substr(spacePos + 1);
                    solve.addEdge(literal1, literal2);
                }
            }
            cout << "Answer:" << endl;
            solve.print();
        }
    }
    return 0;
}
