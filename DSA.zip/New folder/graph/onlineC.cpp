#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

bool isValid(int x, int y,vector<vector<int>>death, int n, int m) {
    if(x >= 0 && x < n && y >= 0 && y < m && (death[x][y]) != -1){
        return true;
    }
    else return false;
}

class cell{
public:
int x;
int y;
cell(int a,int b){
    x=a;
    y=b;
}
};

class rider{
public:
    int x;
    int y;
    int k;

    rider(int a,int b,int c){
    x=a;
    y=b;
    k=c;
    }

};
vector<vector<int>> bfs(int x, int y,vector<vector<int>>death, int n, int m) {
    vector<vector<int>>distances(n, vector<int>(m, -1));
    int dx[]={1,1,2,2,-1,-1,-2,-2};
    int dy[]={2,-2,1,-1,2,-2,1,-1};
    queue<cell> q;
    if(isValid(x,y,death,n,m)){
    q.push(cell(x,y));
    distances[x][y] = 0;
    }

    while (!q.empty()) {
        int cx = q.front().x;
        int cy = q.front().y;
        q.pop();

        for (int i=0;i<8;i++) {
            int nx = cx + dx[i];
            int ny = cy + dy[i];

            if (isValid(nx, ny,death, n, m) && distances[nx][ny] == -1) {
                distances[nx][ny] = distances[cx][cy] + 1;
                q.push({nx, ny});
            }
        }
    }

    return distances;
}
int solve(int n, int m, int q,vector<vector<int>>death,vector<rider>riders) {
    int totalMinMoves = INT_MAX;

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            int minMoves = 0;
            bool isValidCell = true;
            for (int p=0;p < q;p++) {
                 const int x = riders[p].x;
                 const  int y = riders[p].y;
                 const int k = riders[p].k;

                vector<vector<int>> distances = bfs(x, y,death, n, m);

                if (distances[i][j] == -1) {
                    isValidCell = false;
                    break;
                }

                minMoves += (distances[i][j] + k - 1) / k;
            }

            if (isValidCell) {
                totalMinMoves = min(totalMinMoves, minMoves);
            }
        }
    }

    return (totalMinMoves != INT_MAX) ? totalMinMoves : -1;
}
int main() {
    freopen("inputC.txt", "r", stdin);
    freopen("outputC.txt", "w", stdout);

    while (!feof(stdin)) {
        char p;
        cin >> p;
        if (feof(stdin))
            break;
        if (p == 'R') {
            int n, m, q;
            cin >> n >> m >> q;
            vector<vector<int>>death(n,vector<int>(m, 0));
            vector<rider>riders;
            for (int i = 0; i < q; ++i) {
            int x,y,k;
            cin >> x >> y >> k;
            riders.push_back(rider(x,y,k));
            }
            int p;
            cin>>p;
            for(int i=0;i<p;i++){
            int x,y;
            cin>>x>>y;
            death[x][y]=-1;
            }
            int result = solve(n, m, q ,death, riders);
            cout << "Ans:" << result << endl;
        }
    }
    return 0;
}
