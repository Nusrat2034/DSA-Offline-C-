include <bits/stdc++.h>
using namespace std;
class SAT
{
public:
    unordered_map<int, list<int>>graph;
    unordered_map<int, list<int>>reversed_graph;
    stack<int>st;
    unordered_map<int,bool>visited;
    vector<int> component;
    vector<int>answer;
    int n;

    SAT(int n)
    {
        this->n=n;
        component.resize(2 * n);
        answer.resize(n);

    }
    void addEdge(int s,int d)
    {
        graph[s].push_back(d);
        reversed_graph[d].push_back(s);
    }

    void topoSort(int node)
    {
        visited[node]=true;
        for(auto nbr:graph[node])
        {
            if(!visited[nbr])
            {
                topoSort(nbr);
            }
        }
        st.push(node);
    }

    void scc(int node,int sccno)
    {
        visited[node]=true;
        component[node]=sccno;
        for(auto x:reversed_graph[node])
        {
            if(!visited[x])
            {
                scc(x,sccno);
            }
        }
    }

    bool isSatisfiable()
    {
        visited.clear();
        visited.reserve(2 * n);
        for (int i = 0; i < 2 * n; ++i)
        {
            visited[i] = false;
        }
        for (int i = 0; i < 2 * n; ++i)
        {
            if (!visited[i])
            {
                topoSort(i);
            }
        }

        visited.clear();
        visited.reserve(2 * n);
        for (int i = 0; i < 2 * n; ++i)
        {
            visited[i] = false;
        }

        int sccno = 0;
        component.assign(2 * n, -1);
        while (!st.empty())
        {
            int v = st.top();
            st.pop();
            if (!visited[v])
            {
                scc(v, sccno++);
            }
        }

        answer.resize(n);
        for (int i = 0; i < n; i++)
        {
            if (component[i] == component[i + n])
            {
                return false;
            }
            answer[i] = (component[i] > component[i + n] ? 1 : 0);
        }

        return true;
    }
};
int main()
{
    unordered_map<int, bool> isPushed;
    int n;
    cin >> n;
    cin.ignore();
    SAT sat(n);
    unordered_set<char>charset;
    for (int i = 0; i < n; ++i)
    {
        string clause;
        getline(cin, clause);
        clause.erase(remove_if(clause.begin(), clause.end(), [](unsigned char c)
        {
            return isspace(c);
        }),
        clause.end());
        int var1, var2;
        if (clause.length() == 4)
        {
            charset.insert(clause[1]);
            var1 = -((clause[1] - 'a') + 1);
            charset.insert(clause[3]);
            var2 = -((clause[3] - 'a') + 1);
        }
        else if (clause.length() == 3)
        {
            if (clause[0] == '~')
            {
                charset.insert(clause[1]);
                var1 = -((clause[1] - 'a') + 1);
                charset.insert(clause[2]);
                var2 = (clause[2] - 'a') + 1;
            }
            else if (clause[1] == '~')
            {
                charset.insert(clause[0]);
                var1 = (clause[0] - 'a') + 1;
                charset.insert(clause[2]);
                var2 = -((clause[2] - 'a') + 1);
            }
        }
        else if (clause.length() == 2)
        {
            if (clause[0] == '~')
            {
                charset.insert(clause[1]);
                var1 = -((clause[1] - 'a') + 1);
                charset.insert(clause[1]);
                var2 = -((clause[1] - 'a') + 1);
            }
            else
            {
                charset.insert(clause[0]);
                var1 = (clause[0] - 'a') + 1;
                charset.insert(clause[1]);
                var2 = (clause[1] - 'a') + 1;
            }
        }
        else
        {
            charset.insert(clause[0]);
            var1 = (clause[0] - 'a') + 1;
            charset.insert(clause[0]);
            var2 = (clause[0] - 'a') + 1;
        }
        sat.addEdge(-var1,var2);
        if (var1 != var2)
        {
            sat.addEdge(-var2, var1);
        }
    }
    vector<int> ans;
    if (sat.isSatisfiable())
    {
        ans = sat.answer;
       for(int i=0;i<ans.size();i++){
        if()
       }
    }
    else
    {
        cout << "No assignment possible." << endl;
    }

    return 0;
}
